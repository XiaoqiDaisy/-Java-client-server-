package finalproject.client;

import java.awt.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

import finalproject.db.DBInterface;
import finalproject.entities.Person;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Socket;

public class ClientInterface extends JFrame{

	private static final long serialVersionUID = 1L;

	public static final int DEFAULT_PORT = 8001;

	private static final int FRAME_WIDTH = 600;
	private static final int FRAME_HEIGHT = 400;
	final int AREA_ROWS = 8;
	final int AREA_COLUMNS = 40;
	private static final String host = "localhost";


	JComboBox<String> peopleSelect;
	JFileChooser jFileChooser;
	JLabel dbName,connName;
	JButton connectOpenBtn,connectCloseBtn,sendBtn,queryBtn;
	JTextArea logArea;

	Connection conn;

	Socket socket;
	int port;
	boolean connect = false;
	DataInputStream receiveStream;
	ObjectOutputStream sendStream;

	public ClientInterface() {
		this(DEFAULT_PORT);
	}

	public ClientInterface(int port) {
		this.port = port;

		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		menuBar.add(createFileMenu());

		add(managerJPanel(),BorderLayout.NORTH);
		add(showLogJPanel(),BorderLayout.CENTER);

		try {
			jFileChooser = new JFileChooser(new File("").getCanonicalPath());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Component showLogJPanel() {
		JPanel showLogJPanel = new JPanel();
		logArea = new JTextArea(AREA_ROWS, AREA_COLUMNS);
		logArea.setEditable(false);
		showLogJPanel.add(logArea);
		return showLogJPanel;
	}

	private Component managerJPanel() {
		JPanel managerJPanel = new JPanel();
		managerJPanel.setLayout(new GridLayout(5, 1));

		dbName = new JLabel("",JLabel.CENTER);
		this.setDbName(null);
		managerJPanel.add(dbName);

		connName = new JLabel("",JLabel.CENTER);
		this.setConnName(null);
		managerJPanel.add(connName);

		peopleSelect = new JComboBox();
		peopleSelect.addItem("<Empty>");
		managerJPanel.add(peopleSelect);
		JPanel selectPane3 = new JPanel();
		selectPane3.add(peopleSelect);
		managerJPanel.add(selectPane3);

		JPanel connectJPanel = new JPanel();
		connectOpenBtn = new JButton("Open Connection");
		connectCloseBtn = new JButton("Close Connection");
		connectOpenBtn.addActionListener(new OpenButtonListener());
		connectCloseBtn.addActionListener(new CloseButtonListener());
		connectJPanel.add(connectOpenBtn);
		connectJPanel.add(connectCloseBtn);
		managerJPanel.add(connectJPanel);

		JPanel dbManagerJPanel = new JPanel();
		sendBtn = new JButton("Send");
		queryBtn = new JButton("Query");
		sendBtn.addActionListener(new SendButtonListener());
		queryBtn.addActionListener(new QueryButtonListener());
		dbManagerJPanel.add(sendBtn);
		dbManagerJPanel.add(queryBtn);
		managerJPanel.add(dbManagerJPanel);

		return managerJPanel;
	}

	public JMenu createFileMenu() {
		JMenu menu = new JMenu("File");
		menu.add(createFileOpenItem());
		menu.add(createFileExitItem());
		return menu;
	}

	private void fillComboBox() throws SQLException {
		List<ComboBoxItem> list = getNames();
		if (list.isEmpty()) {
			peopleSelect.addItem("<Empty>");
		}else {
			peopleSelect.setModel(new DefaultComboBoxModel(list.toArray()));
		}
	}

	private JMenuItem createFileOpenItem() {
		JMenuItem item = new JMenuItem("Open DB");
		class OpenDBListener implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				int returnVal = jFileChooser.showOpenDialog(getParent());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					System.out.println("You chose to open this file: " + jFileChooser.getSelectedFile().getAbsolutePath());
					String dbFileName = jFileChooser.getSelectedFile().getAbsolutePath();
					try {
						connectToDB(dbFileName);
						if (dbFileName.contains("/")) {
							dbFileName = dbFileName.substring(dbFileName.lastIndexOf("/") + 1);
						} else if (dbFileName.contains("\\")) {
							dbFileName = dbFileName.substring(dbFileName.lastIndexOf("\\") + 1);
						}
						setDbName(dbFileName);
						fillComboBox();

					} catch (Exception e) {
						System.err.println("error connection to db: " + e.getMessage());
						e.printStackTrace();
						setDbName(null);
//						clearComboBox();
					}

				}
			}
		}

		item.addActionListener(new OpenDBListener());
		return item;
	}

	private void connectToDB(String dbFileName) throws SQLException, ClassNotFoundException {
		DBInterface db = new DBInterface(dbFileName);
		db.setConnection();
		conn = db.getConn();
	}


	private JMenuItem createFileExitItem() {
		JMenuItem item = new JMenuItem("Exit");
		item.addActionListener(e -> System.exit(0));
		return item;
	}


	private Person parsePerson(ResultSet resultSet ) throws SQLException {
		Person p = new Person();
		p.setId(resultSet.getInt("id"));
		p.setFirst(resultSet.getString("first"));
		p.setLast(resultSet.getString("last"));
		p.setAge(resultSet.getInt("age"));
		p.setCity(resultSet.getString("city"));
		p.setSent(resultSet.getBoolean("sent"));
		return p;
	}

	class SendButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				// responses are going to come over the input as text, and that's tricky,
				// which is why I've done that for you:
//				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

				// now, get the person on the object dropdownbox we've selected
				ComboBoxItem comboBoxItem = (ComboBoxItem) peopleSelect.getSelectedItem();

				// That's tricky which is why I have included the code. the personEntry
				// contains an ID and a name. You want to get a "Person" object out of that
				// which is stored in the database
				PreparedStatement preparedStatement = conn.prepareStatement("select * from People where id = ?");
				preparedStatement.setInt(1, comboBoxItem.getId());
				ResultSet resultSet = preparedStatement.executeQuery();
				Person p = null;
				if (resultSet.next()) {
					p = parsePerson(resultSet);
				}
				if (p == null) {
					logArea.append("Data Error\n");
					return;
				}

				sendStream.writeObject(p);
				sendStream.flush();
				// update DB
				preparedStatement = conn.prepareStatement("update People set sent = ? where id = ?");
				preparedStatement.setBoolean(1, true);
				preparedStatement.setInt(2, comboBoxItem.getId());
				preparedStatement.executeUpdate();

				fillComboBox();
				// Send the person object here over an output stream that you got from the socket.
				String response = receiveStream.readUTF();
				if (response.contains("Success")) {
					System.out.println("Success");
					// what do you do after we know that the server has successfully
					// received the data and written it to its own database?
					// you will have to write the code for that.
				} else {
					System.out.println("Failed");
				}
			} catch (IOException |SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	private class QueryButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			try {
				ResultSet resultSet = conn.createStatement().executeQuery("select * from People");

				List<String> headers = new ArrayList<>();
				ResultSetMetaData metaData = resultSet.getMetaData();
				int headerCount = metaData.getColumnCount();
				for (int i = 0; i < headerCount; i++) {
					headers.add(metaData.getColumnName(i+1).trim());
				}

				List<List<Object>> valueLists = new ArrayList<>();
				while (resultSet.next()) {
					List<Object> list = new ArrayList<>();
					for (int i = 0; i < headerCount; i++) {
						Object object = resultSet.getObject(i + 1);
						list.add(object);
					}
					valueLists.add(list);
				}

				String tpl = "";
				for (int i = 0; i < headerCount; i++) {
					tpl = tpl + "%s\t";
				}
				tpl += "\n";

				StringBuffer buffer = new StringBuffer(String.format(tpl, headers.toArray(new String[0])));
				for (int i = 0; i < valueLists.size(); i++) {
					buffer.append(String.format(tpl, valueLists.get(i).toArray(new Object[0])));
				}
				fillComboBox();
				logArea.setText(buffer.toString());
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}


	class OpenButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				if (connect) {
					return;
				}
				socket = new Socket(host, port);
				receiveStream = new DataInputStream(socket.getInputStream());
				sendStream = new ObjectOutputStream(socket.getOutputStream());
				setConnName(host + ":" + port);
				connect = true;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	class CloseButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				socket.close();
				setConnName(null);
				connect = false;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	private List<ComboBoxItem> getNames() throws SQLException {
		List<ComboBoxItem> comboBoxItemList = new ArrayList<>();
		Statement selectName = conn.createStatement();
		ResultSet resultSet = selectName.executeQuery("select * from people where sent = 0");
		while (resultSet.next()) {
			Person person = parsePerson(resultSet);
			comboBoxItemList.add(new ComboBoxItem(person.getId(), person.getFirst()+" "+person.getLast()));
		}
		return comboBoxItemList;
	}

	// a JComboBox will take a bunch of objects and use the "toString()" method
	// of those objects to print out what's in there. 
	// So I have provided to you an object to put people's names and ids in
	// and the combo box will print out their names. 
	// now you will want to get the ComboBoxItem object that is selected in the combo box
	// and get the corresponding row in the People table and make a person object out of that.
	class ComboBoxItem {
		private int id;
		private String name;

		public ComboBoxItem(int id, String name) {
			this.id = id;
			this.name = name;
		}

		public int getId() {
			return this.id;
		}

		public String getName() {
			return this.name;
		}

		public String toString() {
			return this.name;
		}
	}

	private void setDbName(String value) {
		if (value == null) {
			value = "<None>";
		}
		dbName.setText("DB: " + value);
	}

	private void setConnName(String value) {
		if (value == null) {
			value = "<None>";
		}
		connName.setText("Active Connection: " + value);
	}

	public static void main(String[] args) {
		ClientInterface ci = new ClientInterface();
		ci.setVisible(true);
	}

}
