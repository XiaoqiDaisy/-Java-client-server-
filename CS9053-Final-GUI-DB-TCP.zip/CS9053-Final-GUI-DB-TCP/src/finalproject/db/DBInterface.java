package finalproject.db;
import java.sql.*;
import java.util.ArrayList;

import finalproject.entities.Person;

public class DBInterface {

	/* implementing or using this class isn't strictly required, but
	 * you might want to abstract some of the interactions with and queries
	 * to the database to a separate class.
	 */
	
	Connection conn;
	String dbUrl;
	
	public DBInterface() {
	}

	public DBInterface(String dbFileName) throws SQLException, ClassNotFoundException {
		String dbUrl = "jdbc:sqlite:" + dbFileName;
		conn = DriverManager.getConnection(dbUrl);
	}

	public Connection getConn() {
		return this.conn;
	}
	
	public void setConnection() throws SQLException {
		if (conn == null) {
			conn = DriverManager.getConnection(dbUrl);
		}
	}
	
}
